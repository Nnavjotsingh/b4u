import { Component ,OnInit} from '@angular/core';
import { ModalController ,NavController,AlertController} from '@ionic/angular';
import { AllOrderPage } from '../all-order/all-order.page';
import { NgModule } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';




@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page  {
  
  constructor(
    // private modalCtrl:ModalController,
    // private http:HttpClient,
    
    
    
    private navctrl: NavController,
    // private alertCtrl: AlertController
    
  ) {}

  allOrder(){
   
    this.navctrl.navigateRoot('/all-order');
    // this.modalCtrl.create({
    //   component: AllOrderPage
    // })
    //   .then(modal => modal.present());
  }
}
