import { NgModule, } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AddCartCakePage } from './add-cart-cake/add-cart-cake.page';
import { AddItemPage } from './add-item/add-item.page';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';



@NgModule({
  declarations: [AppComponent, AddCartCakePage, AddItemPage],
  entryComponents: [AddCartCakePage, AddItemPage],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    Camera,
    
        File

  ],
  providers: [{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }],
  bootstrap: [AppComponent],
})
export class AppModule {}
