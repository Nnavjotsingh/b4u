import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AlertController, ModalController } from '@ionic/angular';
import { OrderService } from '../order.service';


@Component({
  selector: 'app-add-cart-cake',
  templateUrl: './add-cart-cake.page.html',
  styleUrls: ['./add-cart-cake.page.scss'],
})
export class AddCartCakePage implements OnInit {

  id: any;
  item: any;
  qnty: any;
  price: any;
  amt: any;
  descc: any;
  pond: any;
  flvr: any;
  file: any;
  constructor(public orderService: OrderService, private alertCtrl: AlertController, 
    private modalCtrl: ModalController,
    private http: HttpClient,
    ) { }

  ngOnInit() {
  }
  close(){
    this.modalCtrl.dismiss();
  }
  onSubmit() {
    let data: any = {
      item: 'Cake',
      qnty: '1',
      price: this.amt,
      amt: this.amt,
      descc: this.descc,
      pond: this.pond,
      flvr: this.flvr,
      file: this.file
    };
    this.orderService.saveaddcartcake(data);
    this.alertCtrl.create({
      header: 'Add',
      message: 'Cake Added Successfully',
      buttons: [
        {
          text: 'Yes'
        }
      ]
    }).then(alertE1 => alertE1.present());

  }
  
}
