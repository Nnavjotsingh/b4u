import { Component, OnInit } from '@angular/core';
import { ModalController, AlertController, NavController } from '@ionic/angular';
import { AddCartCakePage } from '../add-cart-cake/add-cart-cake.page';
import { items as orderItem,carts, cheifs,OrderService } from '../order.service';
import { AddCartItemPage } from '../add-cart-item/add-cart-item.page';
import { HttpClient } from '@angular/common/http';
import { AddItemPage } from '../add-item/add-item.page';



export interface items {
  id: string;
  name: string;
  price: string;
  des: string;
}

export interface cart{
  id:string;
  item:string;
amt:string;
price:string;

}

export interface chiefs{
  id:string;
  name:string;
  
}

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit {

  bal:any;
  rec:any;
  
  carts: carts[];
  totalAmount : number = 0;
  
  constructor(
    private service: OrderService,
    private modalCtrl: ModalController,
    private http: HttpClient,
    private navctrl: NavController,
    private alertCtrl: AlertController,
   
  ) { }

  cheifs: cheifs[];
  items: items[];
  selectedItem: any;

  add_Item() {
    this.navctrl.navigateRoot('/add-item');
  }

  addcartcake() {
    this.modalCtrl.create({
      component: AddCartCakePage
    })
      .then(modal => modal.present());
  }

  addcartitem() {
    this.modalCtrl.create({
      component: AddCartItemPage
    })
      .then(modal => modal.present());
  }

  ngOnInit() {
    this.service.getallcart().subscribe(response => {
      this.carts = response;
    this.totalAmount =   Object.entries(this.carts).reduce((prev,current)=>{
      console.log(current);
        return  prev + parseInt(current[1].amt);
      },0)
    })

   this.service.getallcheif().subscribe(response => {
     this.cheifs = response;
     
   }); 
  }

  //this.modalCtrl.dismiss(null,'close');
  //console.log("btn clicked");
  // this.router.navigateByUrl('')
  removecart(id: string) {
    this.alertCtrl.create({
      header: 'Delete',
      message: 'Are you sure you want to delete?',
      buttons: [
        {
          text: 'Yes',
          handler: () => {
            this.service.removecart(id).subscribe(() => {
              this.carts = this.carts.filter(itd => itd.id !== id);
            });
          }
        },
        { text: 'No' }
      ]
    }).then(alertE1 => alertE1.present());

  }

  // amtItem(id:string,item:string,amt:string){
  //   this.alertCtrl.create(
  //   )
  // }

  // OnInint(id:string){
  //   this.service.getall().subscribe(response => {
  //     console.log("res", response)
  //     this.items = response;)
  //   }

  //   if(this.items && this.amt)
  //    this.amount = this.items * this.price;
  // }
  balance(){
    if(this.totalAmount && this.rec)
    this.bal = this.totalAmount - this.rec

  }

}