import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ModalController } from '@ionic/angular';

export interface items {
  id: string;
  name: string;
  price: string;
  des: string;
}

export interface cheifs {
  id: string;
  Name: string;
  Mobile: string;
  Email: string;
  Password: string;
}


export interface carts {
  id: string;
  item: string;
  qnty: string;
  price: string;
  amt: string;
  descc: string;
  pond: string;
  flvr: string;
  file: string;
}

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private url = 'https://www.bake4u.online/order/';
  constructor(private http: HttpClient, private modalCtrl: ModalController) { }


  getall() {
    return this.http.get<[items]>(this.url + '/item');
  }
  remove(id: string) {
    return this.http.delete(this.url + '/item/' + id);
  }
  savedata(postData) {
    this.http.post(this.url + '/item/', postData).subscribe((data) => {
      console.log("data", data);
    })
  }

  updatedata(item) {
    this.http.put(this.url + '/item/' + item.id, item).subscribe((data) => {
      this.modalCtrl.dismiss();
      console.log("data", data);
    })
  }


  // Cheif Coding

  getallcheif() {
    return this.http.get<[cheifs]>(this.url + '/cheif');
  }

  removeCh(id: string) {
    return this.http.delete(this.url + '/cheif/' + id);
  }

  savedatach(postData) {
    this.http.post(this.url + '/cheif/', postData).subscribe((data) => {
      console.log("data", data);
    })
  }

  updatedatach(cheif) {
    this.http.put(this.url + '/cheif/' + cheif.id, cheif).subscribe((data) => {
      this.modalCtrl.dismiss();
      console.log("data", data);
    })
  }


  // Add Cart Cake

  getallcart() {
    return this.http.get<[carts]>(this.url + '/cart');
  }

  saveaddcartcake(postData) {
    this.http.post(this.url + '/cart/', postData).subscribe((data) => {
      console.log("data", data);
    })
  }

  saveaddcart(post) {
    this.http.post(this.url + '/cart', post).subscribe((data) => {
      console.log("data", data)
    })
  }

  removecart(id:string){
    return this.http.delete(this.url + '/cart/' + id);
  }

}

