import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-all-order',
  templateUrl: './all-order.page.html',
  styleUrls: ['./all-order.page.scss'],
})
export class AllOrderPage implements OnInit {

  constructor(
    private model:ModalController,
    private http:HttpClient,
  ) { }

  ngOnInit() {
    // stop(){
    //   this.model.dismiss();
    // }
  }
  
}
